# HandDetection > 2025-01-18 5:33pm
https://universe.roboflow.com/cheka-low-yel2d/handdetection-ctsxm

Provided by a Roboflow user
License: CC BY 4.0

